module Swd
  # Gets percentage based on numerator and denominator
  def self.get_percentage(num, denom)
    return num * 100 / denom
  end
  
  # Inserts Hash, with values of Integers.
  # Returns the key that corresponds to the right number
  def self.weighted_hash(hash, amount = 0)
    not_array = false
    if amount == 0
      amount = 1
      not_array = true
    end
    denom = 0
    for i in hash.values
      denom += i
    end
    nums = []
    ret  = []
    amount.times do
      nums.push(rand(denom))
      ret.push(nil)
    end
    for k in hash.keys.shuffle
      for n_i in 0...nums.length
        next if ret[n_i]
        num = n_i
        if num < hash[k]
          ret[n_i] = k
          break unless nums.include?(nil)
          next
        end
        nums[n_i] = num - hash[k]
      end
    end
    ret = ret[0] if not_array
    return ret
  end

  # eg. "one/two/three.txt" => ["one/two/", "three.txt"]
  # Used for Bitmaps
  def self.split_file(file)
    unless file.ends_with?("/") || file.ends_with?(".png")
      file += ".png"
    end
    p = file
    f = ""
    unless file.ends_with?("/") # Isn't just a directory
      split_file = file.split(/[\\\/]/)
      f = split_file.pop
      p = split_file.join("/") + "/"
    end
    return [p, f]
  end
  
  def self.save_data(f, data)
    f += ".dat" unless f.ends_with?(".dat")
    File.delete(f) if FileTest.exist?(f)
    save_data(f, data)
  end
  
  # Reads all files in directory
  def self.dir_files(directory, formats = "txt")
    unless formats.is_a?(Array)
      formats = "*." + formats
      formats = [formats]
    end
    count = 0
    files = []
    Dir.chdir(directory){
      for i in 0...formats.length
        Dir.glob(formats[i]){|f| files.push(f) }
      end
    }
    return files
  end
end

# Allows you to use eval without risking the game crashing
def secure_eval(str, return_if_fail = nil)
  eval("defined?(#{str})") ? eval(str) : return_if_fail
end